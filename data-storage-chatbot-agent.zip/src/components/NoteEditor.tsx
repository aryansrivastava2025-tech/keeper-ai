import React, { useState } from 'react';
import { Note } from '../types';
import { FileText, Plus, Trash2, Edit2, Check, BookOpen, Save } from 'lucide-react';

interface NoteEditorProps {
  notes: Note[];
  onAdd: (title: string, content: string) => void;
  onUpdate: (id: string, updates: Partial<Note>) => void;
  onDelete: (id: string) => void;
}

export default function NoteEditor({ notes, onAdd, onUpdate, onDelete }: NoteEditorProps) {
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const selectedNote = notes.find(n => n.id === selectedNoteId);

  // Markdown formatting logic helper (custom high performance lightweight renderer)
  const renderMarkdown = (text: string) => {
    if (!text) return null;
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      // Headers
      if (line.startsWith('# ')) {
        return <h1 key={idx} className="text-xl font-display font-bold text-slate-800 mt-4 mb-2 border-b border-slate-200 pb-1">{line.slice(2)}</h1>;
      }
      if (line.startsWith('## ')) {
        return <h2 key={idx} className="text-lg font-display font-semibold text-slate-800 mt-3 mb-1.5">{line.slice(3)}</h2>;
      }
      if (line.startsWith('### ')) {
        return <h3 key={idx} className="text-sm font-display font-semibold text-slate-700 mt-2 mb-1">{line.slice(4)}</h3>;
      }
      // Bullet items
      if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
        return (
          <li key={idx} className="list-disc list-inside text-xs text-slate-600 ml-2 py-0.5 font-sans">
            {line.trim().slice(2)}
          </li>
        );
      }
      // Numbered List
      if (/^\d+\.\s/.test(line.trim())) {
        const text = line.trim().replace(/^\d+\.\s/, '');
        return (
          <li key={idx} className="list-decimal list-inside text-xs text-slate-600 ml-2 py-0.5 font-sans">
            {text}
          </li>
        );
      }
      // Blockquote
      if (line.startsWith('> ')) {
        return (
          <blockquote key={idx} className="border-l-4 border-blue-500 pl-3 py-1.5 my-2 bg-blue-50/50 text-xs italic text-slate-500 rounded-r-lg font-sans">
            {line.slice(2)}
          </blockquote>
        );
      }
      // Code snippet
      if (line.startsWith('```')) {
        return null; // Ignore fence lines in list
      }
      // Regular text (handle bold **text** in lines)
      const boldRegex = /\*\*(.*?)\*\*/g;
      const parts = [];
      let lastIndex = 0;
      let match;
      while ((match = boldRegex.exec(line)) !== null) {
        if (match.index > lastIndex) {
          parts.push(line.substring(lastIndex, match.index));
        }
        parts.push(<strong key={match.index} className="font-bold text-slate-900">{match[1]}</strong>);
        lastIndex = boldRegex.lastIndex;
      }
      if (lastIndex < line.length) {
        parts.push(line.substring(lastIndex));
      }

      return (
        <p key={idx} className="text-xs text-slate-600 leading-relaxed font-sans py-1 min-h-[1.5rem] select-text font-medium">
          {parts.length > 0 ? parts : line}
        </p>
      );
    });
  };

  const handleSelectNote = (id: string) => {
    setSelectedNoteId(id);
    setIsEditing(false);
    setIsAdding(false);
    const note = notes.find(n => n.id === id);
    if (note) {
      setTitle(note.title);
      setContent(note.content);
    }
  };

  const handleStartAdd = () => {
    setIsAdding(true);
    setSelectedNoteId(null);
    setIsEditing(false);
    setTitle('');
    setContent('');
  };

  const handleSave = () => {
    if (!title.trim() || !content.trim()) return;
    if (isAdding) {
      onAdd(title.trim(), content.trim());
      setIsAdding(false);
      // Select the newly added note by selecting the latest note in next render (or we'll let user re-click)
    } else if (selectedNoteId) {
      onUpdate(selectedNoteId, { title: title.trim(), content: content.trim() });
      setIsEditing(false);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(id);
    if (selectedNoteId === id) {
      setSelectedNoteId(null);
      setIsEditing(false);
      setTitle('');
      setContent('');
    }
  };

  return (
    <div className="flex bg-white border border-slate-200 rounded-2xl overflow-hidden h-full shadow-sm font-sans">
      {/* Sidebar List */}
      <div className="w-1/3 border-r border-slate-200 flex flex-col h-full bg-slate-50/25 shrink-0">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-blue-600" />
            <h3 className="font-display font-semibold text-sm text-slate-800">Documents</h3>
          </div>
          <button
            onClick={handleStartAdd}
            className="p-1.5 hover:bg-white hover:text-blue-600 text-slate-500 border border-slate-200 hover:border-slate-300 rounded-lg transition shrink-0 cursor-pointer bg-slate-50"
            title="Create new note"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {notes.length === 0 ? (
            <div className="text-center py-8 px-2">
              <p className="text-[11px] text-slate-500 font-medium">No notes drafted.</p>
              <button 
                onClick={handleStartAdd}
                className="text-[10px] text-blue-600 hover:underline mt-1 cursor-pointer font-bold"
              >
                Draft first note
              </button>
            </div>
          ) : (
            notes.map(note => (
              <div
                key={note.id}
                onClick={() => handleSelectNote(note.id)}
                className={`p-2.5 rounded-xl cursor-pointer text-left transition duration-150 flex items-start justify-between gap-2 border ${
                  selectedNoteId === note.id
                    ? 'bg-blue-50 border-blue-200 text-blue-900 shadow-xs'
                    : 'bg-transparent border-transparent hover:bg-slate-50 hover:text-slate-850 text-slate-600'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <h4 className="text-xs font-semibold truncate font-display">{note.title}</h4>
                  <p className="text-[10px] text-slate-400 truncate font-sans mt-0.5">{note.content}</p>
                </div>
                <button
                  onClick={(e) => handleDelete(note.id, e)}
                  className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition whitespace-nowrap shrink-0 cursor-pointer"
                  title="Remove document"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Detail Area */}
      <div className="flex-1 flex flex-col h-full bg-white overflow-hidden">
        {selectedNote || isAdding ? (
          <div className="flex flex-col h-full overflow-hidden">
            {/* Toolbar */}
            <div className="p-3 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between shrink-0">
              <span className="text-[10px] font-mono text-slate-500">
                {isAdding 
                  ? 'Drafting Document' 
                  : `Last saved: ${new Date(selectedNote?.updatedAt || Date.now()).toLocaleTimeString()}`
                }
              </span>
              <div className="flex gap-2">
                {!isEditing && !isAdding ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 hover:text-blue-600 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition shadow-xs"
                  >
                    <Edit2 className="w-3 h-3" /> Edit
                  </button>
                ) : (
                  <button
                    onClick={handleSave}
                    disabled={!title.trim() || !content.trim()}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition shadow-sm"
                  >
                    <Save className="w-3 h-3 text-white" /> Save
                  </button>
                )}
              </div>
            </div>

            {/* Note Editor Header/Title */}
            <div className="px-4 pt-4 shrink-0">
              {isEditing || isAdding ? (
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Note Title..."
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs font-display font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
              ) : (
                <h2 className="text-base font-display font-bold text-slate-800 tracking-tight leading-tight select-text">
                  {selectedNote?.title}
                </h2>
              )}
            </div>

            {/* Note Editor / Note Reader Body */}
            <div className="flex-1 overflow-y-auto p-4">
              {isEditing || isAdding ? (
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Draft note content in Markdown format... (use # for headings, - for lists, or **text** for bold)"
                  className="w-full h-full bg-slate-50 border border-slate-200 p-4 rounded-xl text-xs font-mono text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 resize-none leading-relaxed focus:ring-2 focus:ring-blue-100"
                />
              ) : (
                <div className="space-y-1.5 text-left leading-relaxed">
                  {renderMarkdown(selectedNote?.content || '')}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
            <BookOpen className="w-8 h-8 text-slate-350 mb-2.5 stroke-1" />
            <h4 className="text-xs font-semibold text-slate-500 font-display">No Document Selected</h4>
            <p className="text-[10px] text-slate-400 max-w-[200px] mt-1">
              Select an existing note from the list, or ask Keeper to draft something for you!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
