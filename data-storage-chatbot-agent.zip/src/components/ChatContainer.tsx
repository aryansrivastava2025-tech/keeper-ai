import React, { useEffect, useRef, useState } from 'react';
import { Message } from '../types';
import { 
  Send, 
  Sparkles, 
  Brain, 
  Bot, 
  User, 
  RefreshCw, 
  Layers, 
  Paperclip, 
  X, 
  FileText, 
  Upload,
  Star,
  Users,
  ArrowRight
} from 'lucide-react';

interface ChatContainerProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  onClearHistory: () => void;
  loading: boolean;
  attachedFile: { name: string; size: number; content: string } | null;
  onAttachFile: (file: { name: string; size: number; content: string } | null) => void;
  onOpenCommunityModal?: () => void;
}

export default function ChatContainer({ 
  messages, 
  onSendMessage, 
  onClearHistory, 
  loading,
  attachedFile,
  onAttachFile,
  onOpenCommunityModal
}: ChatContainerProps) {
  const [input, setInput] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hiddenFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !attachedFile) || loading) return;
    onSendMessage(input.trim());
    setInput('');
  };

  const handleSuggestionClick = (text: string) => {
    if (loading) return;
    onSendMessage(text);
  };

  // Drag and drop handlers for Chat Container
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        onAttachFile({
          name: file.name,
          size: file.size,
          content: text
        });
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handlePaperclipClick = () => {
    hiddenFileInputRef.current?.click();
  };

  // Convert function naming to human readable strings
  const getToolDisplayName = (name: string) => {
    switch (name) {
      case 'saveMemory': return 'Save Factual Memory';
      case 'deleteMemory': return 'Delete Memory';
      case 'createNote': return 'Draft Detailed Note';
      case 'updateNote': return 'Revise Document Note';
      case 'deleteNote': return 'Delete Note';
      case 'createTask': return 'Add Checklist Task';
      case 'updateTask': return 'Check Task Status';
      case 'deleteTask': return 'Remove Task';
      default: return name;
    }
  };

  // Format bytes helper
  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    const kbits = bytes / 1024;
    return kbits.toFixed(1) + ' KB';
  };

  return (
    <div 
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
      className="relative flex flex-col h-full bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm font-sans"
    >
      {/* Drag & Drop Visual Backdrop Overlay */}
      {dragActive && (
        <div className="absolute inset-0 bg-blue-600/10 backdrop-blur-xs border-2 border-dashed border-blue-500 z-50 flex flex-col items-center justify-center text-blue-800 select-none pointer-events-none animate-fade-in font-sans">
          <Upload className="w-10 h-10 mb-2 animate-bounce text-blue-600" />
          <p className="text-sm font-bold">Drop text, log or backup files here...</p>
          <p className="text-xs text-blue-500 mt-1">Keeper Agent will read and process them instantly!</p>
        </div>
      )}

      {/* Hidden file input element */}
      <input 
        ref={hiddenFileInputRef}
        type="file"
        onChange={handleFileChange}
        accept=".txt,.md,.json,.csv,.js,.jsx,.ts,.tsx,.py,.html,.css"
        className="hidden"
      />

      {/* Thread Header */}
      <div className="p-4 border-b border-slate-200 bg-slate-50/50 shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 shrink-0 flex items-center justify-center text-white font-bold">
            Σ
          </div>
          <div>
            <h2 className="font-display font-semibold text-sm text-slate-800">Keeper Agent</h2>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Active Workspace</span>
            </div>
          </div>
        </div>

        <button
          onClick={onClearHistory}
          disabled={messages.length === 0}
          className="px-3 py-1.5 text-[11px] font-semibold text-slate-500 hover:text-rose-600 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg cursor-pointer transition disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Reset Session
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 select-none">
            <div className="p-3 bg-blue-50 border border-blue-100 text-blue-600 rounded-2xl mb-4">
              <Brain className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h3 className="text-sm font-display font-semibold text-slate-800">Talk to Information Storage Agent</h3>
            <p className="text-xs text-slate-500 max-w-[280px] mt-1.5 leading-relaxed">
              Tell me things to remember, tasks to do, or notes to write. Or <span className="font-semibold text-blue-600">drag files here</span> to analyze their data in bulk.
            </p>

            {/* Quick Suggestions Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-6 w-full max-w-[420px]">
              {[
                "Remember my birthday is October 15th",
                "Draft a outline note for launching a startup",
                "Create tasks to study react hook, run test and deploy",
                "What did you remember about me?"
              ].map((sug, i) => (
                <button
                  key={i}
                  onClick={() => handleSuggestionClick(sug)}
                  className="p-3 rounded-xl border border-slate-205 hover:border-blue-250 bg-slate-50 hover:bg-blue-50/50 text-left text-[11px] font-sans font-medium text-slate-600 hover:text-blue-800 leading-relaxed cursor-pointer transition duration-150 shadow-xs"
                >
                  {sug} &rarr;
                </button>
              ))}
            </div>

            {/* 100,000 People Community Trust Showcase */}
            {onOpenCommunityModal && (
              <button
                type="button"
                onClick={onOpenCommunityModal}
                className="mt-4 p-2.5 px-3.5 bg-gradient-to-r from-slate-50 via-blue-50/40 to-slate-50 hover:from-blue-50/70 hover:to-indigo-50/60 border border-slate-200/90 hover:border-blue-300 rounded-xl flex items-center justify-between gap-3 w-full max-w-[420px] transition cursor-pointer group shadow-2xs text-left"
              >
                <div className="flex items-center gap-2.5">
                  <div className="flex -space-x-1.5 overflow-hidden shrink-0">
                    <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-blue-600 text-white font-bold text-[9px] items-center justify-center">EV</span>
                    <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-indigo-600 text-white font-bold text-[9px] items-center justify-center">MT</span>
                    <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-emerald-600 text-white font-bold text-[9px] items-center justify-center">SL</span>
                    <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-amber-600 text-white font-bold text-[8.5px] items-center justify-center">+100k</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-850 group-hover:text-blue-700 transition">
                        100,000+ active thinkers
                      </span>
                      <span className="inline-flex items-center gap-0.5 text-[9.5px] font-semibold text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                        <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                        4.9
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-normal mt-0.5">
                      Engineers, researchers, founders & students worldwide
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-[10.5px] font-bold text-blue-650 shrink-0 group-hover:translate-x-0.5 transition">
                  <span className="hidden sm:inline">Milestone</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex gap-3 max-w-[85%] ${
                  msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Speaker Icon */}
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border shadow-xs ${
                  msg.role === 'user' 
                    ? 'bg-slate-100 border-slate-200 text-slate-600' 
                    : 'bg-blue-50 border-blue-100 text-blue-600'
                }`}>
                  {msg.role === 'user' ? (
                    <User className="w-3.5 h-3.5" />
                  ) : (
                    <Bot className="w-3.5 h-3.5" />
                  )}
                </div>

                {/* Message Parts Container */}
                <div className="space-y-1.5">
                  {msg.parts.map((part, pIdx) => {
                    // 1. Tool execution log trigger render
                    if (part.functionCall) {
                      return (
                        <div 
                          key={pIdx} 
                          className="bg-slate-50 border border-slate-205 text-slate-700 rounded-xl p-3 my-1 flex flex-col gap-1.5 shadow-xs min-w-[200px]"
                        >
                          <div className="flex items-center gap-1.5 text-[10px] font-mono text-blue-600 font-bold uppercase tracking-wider">
                            <Layers className="w-3.5 h-3.5 animate-spin" />
                            {getToolDisplayName(part.functionCall.name)}
                          </div>
                          <div className="text-[10px] bg-slate-100/80 px-2 py-1.5 rounded-md font-mono text-slate-700 border border-slate-200">
                            {Object.entries(part.functionCall.args || {}).map(([k, v]) => (
                              <div key={k} className="truncate">
                                <span className="text-slate-450">{k}:</span> {typeof v === 'string' ? `"${v}"` : String(v)}
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    }

                    // 2. Tool response trigger render
                    if (part.functionResponse) {
                      return (
                        <div 
                          key={pIdx} 
                          className="bg-blue-50 border border-blue-100 text-blue-600 rounded-lg px-2.5 py-1 text-[9px] font-mono inline-block shrink-0"
                        >
                          ✔ Database synced successfully
                        </div>
                      );
                    }

                    // 3. Text output renderer
                    if (part.text) {
                      return (
                        <div 
                          key={pIdx} 
                          className={`p-3 rounded-2xl text-xs leading-relaxed select-text font-medium whitespace-pre-wrap ${
                            msg.role === 'user'
                              ? 'bg-blue-50 border border-blue-100 text-slate-800 rounded-tr-none shadow-xs'
                              : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-xs font-sans'
                          }`}
                        >
                          {part.text}
                        </div>
                      );
                    }

                    return null;
                  })}
                </div>
              </div>
            ))}

            {/* Simulated typing status */}
            {loading && (
              <div className="flex gap-3 max-w-[85%] mr-auto items-center animate-pulse">
                <div className="w-7 h-7 rounded-lg bg-slate-100 border border-slate-200 text-blue-600 flex items-center justify-center shrink-0">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 text-slate-500 px-3 py-2 rounded-2xl rounded-tl-none">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce delay-100"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce delay-200"></span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Inputs Bar form */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-slate-200 bg-slate-50/20 shrink-0">
        
        {/* Render floating attachment badge if file is loaded */}
        {attachedFile && (
          <div className="mb-2.5 p-2 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-150 rounded-lg flex items-center justify-between shrink-0 animate-fade-in text-xs font-sans">
            <div className="flex items-center gap-2">
              <div className="p-1 px-1.5 bg-blue-100 border border-blue-200 rounded text-[9.5px] font-mono font-bold uppercase tracking-wider text-blue-700">
                {attachedFile.name.split('.').pop() || 'Text'}
              </div>
              <span className="font-bold text-slate-700 truncate max-w-[200px] sm:max-w-xs">{attachedFile.name}</span>
              <span className="text-[10px] text-slate-450 font-mono">({formatBytes(attachedFile.size)})</span>
            </div>
            <button
              type="button"
              onClick={() => onAttachFile(null)}
              className="p-1 hover:bg-slate-200/55 rounded-full transition cursor-pointer text-slate-450 hover:text-slate-750"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <div className="relative flex items-center gap-2">
          {/* Paperclip upload trigger */}
          <button
            type="button"
            onClick={handlePaperclipClick}
            disabled={loading}
            className="w-10 h-10 shrink-0 bg-slate-100 hover:bg-blue-100/60 text-slate-500 hover:text-blue-650 border border-slate-205 rounded-xl flex items-center justify-center transition cursor-pointer disabled:opacity-50"
            title="Attach a file to assist conversation"
          >
            <Paperclip className="w-4.5 h-4.5" />
          </button>

          <div className="relative flex-1 flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={loading}
              placeholder={
                loading 
                  ? 'Keeper in deep reasoning...' 
                  : attachedFile 
                    ? 'Add instructions for attached file...' 
                    : 'Store notes, tasks, or preferences...'
              }
              className="w-full pl-4 pr-12 py-3 bg-slate-50 border border-slate-355 rounded-xl focus:ring-2 focus:ring-blue-100 focus:border-blue-500 focus:outline-none text-xs transition duration-150 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={(!input.trim() && !attachedFile) || loading}
              className="absolute right-2 top-2 w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center shadow-md disabled:opacity-45 hover:bg-blue-700 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        <p className="text-[10px] text-slate-400 font-sans text-center mt-2.5 select-none uppercase tracking-wider flex items-center justify-center gap-1.5 leading-none">
          <span>Drag-and-drop text/JSON logs directly onto Keeper to analyze or batch import in bulk.</span>
        </p>
      </form>
    </div>
  );
}
