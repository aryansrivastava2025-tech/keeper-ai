import React, { useState } from 'react';
import { Memory } from '../types';
import { BrainCircuit, Trash2, Search, Tag, Sparkles, MessageCircleCode } from 'lucide-react';

interface MemoryListProps {
  memories: Memory[];
  onDelete: (id: string) => void;
  onAdd: (content: string, category: string) => void;
}

export default function MemoryList({ memories, onDelete, onAdd }: MemoryListProps) {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [newContent, setNewContent] = useState('');
  const [newCat, setNewCat] = useState('personal');

  // Derive unique categories plus "All"
  const categories = ['All', ...Array.from(new Set(memories.map(m => m.category)))];

  const filteredMemories = memories.filter(m => {
    const matchesSearch = m.content.toLowerCase().includes(search.toLowerCase()) || 
                          m.category.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || m.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    onAdd(newContent.trim(), newCat);
    setNewContent('');
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden font-sans border border-slate-200 rounded-2xl shadow-sm">
      {/* Header Info */}
      <div className="p-4 border-b border-slate-200 bg-slate-50/50 shrink-0">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-5 h-5 text-blue-600" />
          <h2 className="font-display font-semibold text-base text-slate-800">Factual Memories</h2>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Implicit facts the agent captures and references dynamically during conversation.
        </p>
      </div>

      {/* Manual Quick Add Form */}
      <form onSubmit={handleSubmit} className="p-3 border-b border-slate-200 bg-slate-50/20 shrink-0 flex gap-2">
        <input 
          type="text" 
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
          placeholder="Store a fact manually... (e.g. 'Prefers dark chocolates')"
          className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition duration-150"
        />
        <select 
          value={newCat}
          onChange={(e) => setNewCat(e.target.value)}
          className="px-2 py-1.5 text-xs rounded-lg bg-slate-50 border border-slate-200 text-slate-700 focus:outline-none cursor-pointer"
        >
          <option value="personal">Personal</option>
          <option value="work">Work</option>
          <option value="preference">Preference</option>
          <option value="facts">Fact</option>
          <option value="tech">Tech</option>
        </select>
        <button 
          type="submit" 
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer shrink-0 transition shadow-xs"
        >
          Add
        </button>
      </form>

      {/* Filters & Searching Toolbar */}
      <div className="p-3 border-b border-slate-200 bg-slate-50/10 shrink-0 flex flex-col gap-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search captured knowledge..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition"
          />
        </div>
        
        {/* Horizontal scroll indicators/tags */}
        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold shrink-0 transition cursor-pointer capitalize border ${
                selectedCategory === cat 
                  ? 'bg-blue-50 text-blue-600 border-blue-200 font-bold' 
                  : 'bg-slate-100 text-slate-500 border-transparent hover:text-slate-700 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of memory tags */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredMemories.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4">
            <div className="p-3 bg-slate-50 border border-slate-200 text-slate-400 rounded-full mb-2">
              <Sparkles className="w-5 h-5 text-slate-400 stroke-1" />
            </div>
            <p className="text-xs text-slate-500 font-medium">No recorded memories matching</p>
            <p className="text-[10px] text-slate-450 mt-1 max-w-[200px]">
              Chat with Keeper and mention facts about yourself. The agent will save them!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2.5">
            {filteredMemories.map(mem => (
              <div 
                key={mem.id} 
                className="group p-3 bg-slate-50 hover:bg-blue-50/10 border border-slate-200 rounded-xl flex items-start justify-between gap-3 shadow-none hover:shadow-xs transition-all duration-150"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-200 text-slate-600 border border-slate-300/40 text-[9px] font-mono capitalize">
                      <Tag className="w-2.5 h-2.5" />
                      {mem.category}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono">
                      {new Date(mem.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed font-sans font-medium select-text">
                    {mem.content}
                  </p>
                </div>
                
                <button
                  onClick={() => onDelete(mem.id)}
                  className="p-1 px-1.5 hover:bg-rose-50 hover:text-rose-600 border border-transparent hover:border-rose-200 text-slate-400 rounded-md transition duration-150 cursor-pointer md:opacity-0 group-hover:opacity-100 shrink-0"
                  title="Delete memory"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
