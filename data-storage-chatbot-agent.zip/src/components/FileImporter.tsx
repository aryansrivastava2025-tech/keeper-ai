import React, { useState, useRef } from 'react';
import { 
  FileText, 
  Upload, 
  CheckSquare, 
  BrainCircuit, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  FileCode, 
  Layers, 
  ArrowRight,
  ClipboardCheck,
  Eye
} from 'lucide-react';
import { Memory, Note, Task } from '../types';

interface FileImporterProps {
  userId?: string;
  onAddMemory: (content: string, category: string) => Promise<any>;
  onAddNote: (title: string, content: string) => Promise<any>;
  onAddTask: (title: string) => Promise<any>;
  memories: Memory[];
  notes: Note[];
  tasks: Task[];
  onImportBackup: (backup: { memories?: Memory[]; notes?: Note[]; tasks?: Task[] }) => Promise<void>;
  onAttachToChat: (file: { name: string; size: number; content: string }) => void;
}

export default function FileImporter({
  userId,
  onAddMemory,
  onAddNote,
  onAddTask,
  memories,
  notes,
  tasks,
  onImportBackup,
  onAttachToChat
}: FileImporterProps) {
  const [dragActive, setDragActive] = useState(false);
  const [fileDetails, setFileDetails] = useState<{
    name: string;
    size: number;
    type: string;
    content: string;
  } | null>(null);
  
  const [importType, setImportType] = useState<'note' | 'tasks' | 'memories' | 'backup' | null>(null);
  
  // Custom states for draft parameters
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [parsedLines, setParsedLines] = useState<{ text: string; selected: boolean }[]>([]);
  const [memoryCategory, setMemoryCategory] = useState('imported');
  const [isSuccess, setIsSuccess] = useState(false);
  const [message, setMessage] = useState('');
  const [errorText, setErrorText] = useState('');
  const [previewContent, setPreviewContent] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    setErrorText('');
    setIsSuccess(false);
    setMessage('');
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) {
        setErrorText("This file appears to be empty or cannot be read.");
        return;
      }

      const info = {
        name: file.name,
        size: file.size,
        type: file.type || file.name.split('.').pop() || 'text/plain',
        content: text
      };

      setFileDetails(info);
      setNoteTitle(file.name.replace(/\.[^/.]+$/, "")); // Strip extension for default title
      setNoteContent(text);

      // Guess import strategy based on name or contents
      if (file.name.endsWith('.json')) {
        try {
          const parsed = JSON.parse(text);
          if (parsed.memories || parsed.notes || parsed.tasks) {
            setImportType('backup');
          } else {
            setImportType('note');
          }
        } catch {
          setImportType('note');
        }
      } else {
        const lines = text.split('\n')
          .map(l => l.trim())
          .filter(l => l.length > 0);
        
        // Populate potential todo items
        setParsedLines(lines.map(line => {
          // Strip lists prefixes like "-", "*", "1.", "[ ]"
          let clean = line.replace(/^[-*]\s+(\[ ]|\[x])?\s*/i, '');
          clean = clean.replace(/^\d+\.\s*/, '');
          return { text: clean, selected: true };
        }));

        setImportType('note');
      }
    };

    reader.onerror = () => {
      setErrorText("Error loading file.");
    };

    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileBrowser = () => {
    fileInputRef.current?.click();
  };

  const resetImporter = () => {
    setFileDetails(null);
    setImportType(null);
    setErrorText('');
    setIsSuccess(false);
    setMessage('');
    setParsedLines([]);
    setPreviewContent(false);
  };

  // 1. Direct Markdown Document Import
  const handleSaveAsNote = async () => {
    if (!noteTitle.trim() || !noteContent.trim()) return;
    try {
      await onAddNote(noteTitle.trim(), noteContent);
      setIsSuccess(true);
      setMessage(`Successfully imported "${noteTitle}" as a document note!`);
      setFileDetails(null);
      setImportType(null);
    } catch (err: any) {
      setErrorText(`Failed to save document: ${err.message || err}`);
    }
  };

  // 2. Checklist Lines Import
  const handleSaveAsTasks = async () => {
    const selectedTasks = parsedLines.filter(l => l.selected && l.text.trim());
    if (selectedTasks.length === 0) {
      setErrorText("Please select at least one line item to import.");
      return;
    }
    try {
      for (const t of selectedTasks) {
        await onAddTask(t.text);
      }
      setIsSuccess(true);
      setMessage(`Successfully created ${selectedTasks.length} tasks in your checklist!`);
      setFileDetails(null);
      setImportType(null);
    } catch (err: any) {
      setErrorText(`Failed to save task lists: ${err.message || err}`);
    }
  };

  // 3. Factual Memories Batch Import
  const handleSaveAsMemories = async () => {
    const selectedMemories = parsedLines.filter(l => l.selected && l.text.trim());
    if (selectedMemories.length === 0) {
      setErrorText("Please select at least one statement to import as a fact.");
      return;
    }
    try {
      for (const m of selectedMemories) {
        await onAddMemory(m.text, memoryCategory.trim().toLowerCase() || 'imported');
      }
      setIsSuccess(true);
      setMessage(`Successfully recorded ${selectedMemories.length} facts in your memory database!`);
      setFileDetails(null);
      setImportType(null);
    } catch (err: any) {
      setErrorText(`Failed to save memories: ${err.message || err}`);
    }
  };

  // 4. Full Workspace JSON Backup Restore
  const handleRestoreJsonBackup = async () => {
    if (!fileDetails) return;
    try {
      const data = JSON.parse(fileDetails.content);
      if (!data.memories && !data.notes && !data.tasks) {
        throw new Error("Invalid backup structure. Must contain memories, notes, or tasks collections.");
      }
      await onImportBackup(data);
      setIsSuccess(true);
      setMessage("Workspace database restore completed from JSON backup safely!");
      setFileDetails(null);
      setImportType(null);
    } catch (err: any) {
      setErrorText(`Failed to restore JSON backup: ${err.message || err}`);
    }
  };

  // 5. Connect / Send file content directly into Keeper Agent
  const sendToAgent = () => {
    if (!fileDetails) return;
    onAttachToChat(fileDetails);
    setIsSuccess(true);
    setMessage(`Successfully loaded "${fileDetails.name}" content into Chat Attachment. Look at the chat window below!`);
  };

  // Backup Export Routine
  const handleDownloadBackup = () => {
    const backupData = {
      backupDate: new Date().toISOString(),
      memories,
      notes,
      tasks
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `keeper_database_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Format File Size
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = 1;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden font-sans border border-slate-200 rounded-2xl shadow-sm">
      {/* Header Info */}
      <div className="p-4 border-b border-slate-200 bg-slate-50/50 shrink-0 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            <h2 className="font-display font-semibold text-base text-slate-800 font-sans">File Importer & Backup</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Import text, CSV, lists, or full JSON backups, and let Keeper extract details.
          </p>
        </div>

        <button
          onClick={handleDownloadBackup}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-750 bg-blue-50/60 hover:bg-blue-100 border border-blue-200 rounded-xl transition cursor-pointer shrink-0 shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Backup JSON</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Success / Info Alerts */}
        {isSuccess && (
          <div className="p-3.5 bg-green-50 border border-green-200 text-green-800 rounded-xl flex items-center gap-2.5 shadow-sm text-xs animate-fade-in">
            <CheckCircle2 className="w-4.5 h-4.5 text-green-600 shrink-0" />
            <span className="font-medium">{message}</span>
          </div>
        )}

        {errorText && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-center gap-2.5 shadow-sm text-xs animate-fade-in col-span-2">
            <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0" />
            <span className="font-medium">{errorText}</span>
          </div>
        )}

        {/* Drag and Drop Region */}
        {!fileDetails ? (
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={triggerFileBrowser}
            className={`cursor-pointer border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition min-h-[190px] select-none ${
              dragActive 
                ? 'border-blue-500 bg-blue-50/40 text-blue-800' 
                : 'border-slate-205 hover:border-slate-350 hover:bg-slate-50/40 text-slate-500 bg-slate-50/10'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileInput}
              accept=".txt,.md,.json,.csv,.js,.jsx,.ts,.tsx,.py,.html,.css"
              className="hidden"
            />
            
            <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 mb-3.5 shadow-xs">
              <Upload className="w-6 h-6 stroke-[1.8]" />
            </div>

            <h3 className="text-xs font-semibold text-slate-800 font-sans">
              Drag & Drop files here, or <span className="text-blue-600 hover:underline">Browse files</span>
            </h3>

            <p className="text-[10px] text-slate-400 mt-1.5 font-sans leading-normal">
              Supports .txt, .md, .csv, code files, and exported backup .json
            </p>
          </div>
        ) : (
          /* File Configured Setup */
          <div className="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-sm animate-fade-in flex flex-col max-h-[500px]">
            {/* File header bar */}
            <div className="px-4 py-3 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1 px-1.5 bg-blue-100/60 border border-blue-200/50 rounded text-blue-700 text-[10px] font-mono font-bold tracking-wider uppercase">
                  {fileDetails.name.split('.').pop() || 'TXT'}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 truncate max-w-[200px] sm:max-w-xs">{fileDetails.name}</h4>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{formatBytes(fileDetails.size)}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewContent(!previewContent)}
                  className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-lg text-[10px] font-semibold flex items-center gap-1 transition cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{previewContent ? 'Hide' : 'Code'}</span>
                </button>
                <button
                  onClick={resetImporter}
                  className="px-2 py-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg text-[10px] font-bold cursor-pointer transition border border-transparent"
                >
                  Change File
                </button>
              </div>
            </div>

            {/* Read file text content code output preview block */}
            {previewContent && (
              <div className="bg-slate-900 text-slate-200 font-mono text-[10px] p-3 max-h-[160px] overflow-y-auto border-b border-slate-800 leading-relaxed whitespace-pre select-text">
                {fileDetails.content}
              </div>
            )}

            {/* Selector list of Importing conversion directions */}
            <div className="p-4 bg-slate-50/30 border-b border-slate-200 flex flex-col gap-3 shrink-0">
              <span className="text-[10.5px] font-semibold text-slate-600 uppercase tracking-wider">Choose Import Destination:</span>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                <button
                  onClick={() => setImportType('note')}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition cursor-pointer ${
                    importType === 'note'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-950'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                  }`}
                >
                  <FileText className={`w-4 h-4 ${importType === 'note' ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span className="text-[11px] font-bold">Document Note</span>
                </button>

                <button
                  onClick={() => setImportType('tasks')}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition cursor-pointer ${
                    importType === 'tasks'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-950'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                  }`}
                >
                  <CheckSquare className={`w-4 h-4 ${importType === 'tasks' ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span className="text-[11px] font-bold">Checklist Tasks</span>
                </button>

                <button
                  onClick={() => setImportType('memories')}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition cursor-pointer ${
                    importType === 'memories'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-950'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                  }`}
                >
                  <BrainCircuit className={`w-4 h-4 ${importType === 'memories' ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span className="text-[11px] font-bold">Facts Memories</span>
                </button>

                <button
                  onClick={() => setImportType('backup')}
                  className={`p-3 rounded-xl border text-left flex flex-col gap-1.5 transition cursor-pointer ${
                    importType === 'backup'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-950'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                  }`}
                >
                  <FileCode className={`w-4 h-4 ${importType === 'backup' ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span className="text-[11px] font-bold">Backup Restore</span>
                </button>
              </div>
            </div>

            {/* Custom Input settings based on selected import destination */}
            <div className="flex-1 overflow-y-auto p-4 max-h-[220px]">
              {importType === 'note' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 uppercase mb-1">Document Note Title</label>
                    <input
                      type="text"
                      value={noteTitle}
                      onChange={(e) => setNoteTitle(e.target.value)}
                      placeholder="Note Title"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg hover:border-slate-300 focus:outline-none focus:border-blue-600 bg-white text-slate-850"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 uppercase mb-1">Document Content Editor Preview</label>
                    <textarea
                      rows={5}
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                      className="w-full p-2.5 text-xs border border-slate-200 rounded-lg hover:border-slate-300 focus:outline-none focus:border-blue-600 font-mono text-slate-800 bg-white"
                    />
                  </div>

                  <button
                    onClick={handleSaveAsNote}
                    disabled={!noteTitle.trim() || !noteContent.trim()}
                    className="w-full py-2 bg-blue-650 hover:bg-blue-750 text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition disabled:opacity-45 shadow-sm mt-2"
                  >
                    Save as Document Note Document
                  </button>
                </div>
              )}

              {(importType === 'tasks' || importType === 'memories') && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] font-semibold text-slate-600 uppercase">
                      Select Statements to Import ({parsedLines.filter(l => l.selected).length} selected)
                    </label>
                    
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setParsedLines(prev => prev.map(l => ({ ...l, selected: true })))}
                        className="text-[10px] text-blue-650 hover:underline cursor-pointer font-bold bg-transparent"
                      >
                        All
                      </button>
                      <button
                        type="button"
                        onClick={() => setParsedLines(prev => prev.map(l => ({ ...l, selected: false })))}
                        className="text-[10px] text-slate-500 hover:underline cursor-pointer font-bold bg-transparent"
                      >
                        None
                      </button>
                    </div>
                  </div>

                  {importType === 'memories' && (
                    <div className="mb-2">
                      <label className="block text-[10px] font-semibold text-slate-600 uppercase mb-1">Factual Category Group label</label>
                      <input
                        type="text"
                        value={memoryCategory}
                        onChange={(e) => setMemoryCategory(e.target.value)}
                        placeholder="e.g. personal, tech, checklist"
                        className="w-full sm:w-1/2 px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600 bg-white text-slate-850"
                      />
                    </div>
                  )}

                  <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 max-h-[160px] overflow-y-auto bg-slate-50/20">
                    {parsedLines.map((line, idx) => (
                      <label 
                        key={idx} 
                        className="flex gap-2 p-2.5 hover:bg-slate-50 cursor-pointer text-xs font-sans text-slate-700 select-none items-start"
                      >
                        <input
                          type="checkbox"
                          checked={line.selected}
                          onChange={(e) => {
                            const updated = [...parsedLines];
                            updated[idx].selected = e.target.checked;
                            setParsedLines(updated);
                          }}
                          className="mt-0.5 rounded border-slate-320 text-blue-600 focus:ring-blue-100 w-3.5 h-3.5 cursor-pointer shrink-0"
                        />
                        <span className="truncate">{line.text}</span>
                      </label>
                    ))}
                    {parsedLines.length === 0 && (
                      <div className="p-4 text-center text-xs text-slate-400">
                        No statements extracted from this file.
                      </div>
                    )}
                  </div>

                  {importType === 'tasks' ? (
                    <button
                      onClick={handleSaveAsTasks}
                      className="w-full py-2 bg-blue-650 hover:bg-blue-750 text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition shadow-sm mt-1"
                    >
                      Bulk Import Selected Items as Tasks ({parsedLines.filter(l => l.selected).length})
                    </button>
                  ) : (
                    <button
                      onClick={handleSaveAsMemories}
                      className="w-full py-2 bg-purple-650 hover:bg-purple-750 text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition shadow-sm mt-1 bg-purple-600 hover:bg-purple-700"
                    >
                      Bulk Import Selected Items as Memories ({parsedLines.filter(l => l.selected).length})
                    </button>
                  )}
                </div>
              )}

              {importType === 'backup' && (
                <div className="space-y-4">
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-[11px] leading-relaxed flex gap-2 font-sans">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                    <div>
                      <span className="font-bold">Restore Precaution:</span> This operation extracts memories, document notes, and checklist tasks from the backup JSON and syncs them into your workspace database. Existing IDs matching records will be overwritten safely.
                    </div>
                  </div>

                  <button
                    onClick={handleRestoreJsonBackup}
                    className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold font-sans cursor-pointer transition shadow-sm"
                  >
                    Confirm Restore Workspace Backup
                  </button>
                </div>
              )}
            </div>

            {/* Smart assist direct link block */}
            <div className="px-4 py-3 bg-indigo-50/50 border-t border-slate-200/80 flex items-center justify-between shrink-0 font-sans">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-650 animate-pulse" />
                <span className="text-[10.5px] font-semibold text-slate-500">Need AI parsing?</span>
                <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-mono font-bold font-sans">AI ASSIST</span>
              </div>
              <button
                onClick={sendToAgent}
                className="flex items-center gap-1 px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10.5px] font-bold cursor-pointer transition shadow-xs"
              >
                <span>Attach to Chat</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}

        {/* Informative Assistance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-1 font-sans">
          <div className="p-4 border border-slate-150 rounded-2xl bg-slate-50/20 text-slate-700 hover:border-slate-250 transition flex flex-col gap-2">
            <div className="w-7 h-7 rounded-lg bg-pink-50 border border-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs shadow-xs">
              M
            </div>
            <h4 className="text-xs font-bold text-slate-800 font-sans">Markdown Outlining (.md / .txt)</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
              Import markdown text files as Document Notes. The built-in Note reader renders headers (`#`, `##`), checklist structures, bullet lists, and paragraphs with proper formatting.
            </p>
          </div>

          <div className="p-4 border border-slate-150 rounded-2xl bg-slate-50/20 text-slate-700 hover:border-slate-250 transition flex flex-col gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shadow-xs">
              A
            </div>
            <h4 className="text-xs font-bold text-slate-800 font-sans font-sans">AI Intelligent Multi-Extraction</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
              Click <span className="font-semibold text-indigo-600">Attach to Chat</span> above. It loads the entire file into the Agent's chat box, allowing the AI model to parse complex elements, extract key contacts, set tasks, and remember facts sequentially!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
