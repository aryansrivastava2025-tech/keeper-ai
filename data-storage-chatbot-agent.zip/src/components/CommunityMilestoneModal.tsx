import React, { useEffect } from 'react';
import { 
  Users, 
  Star, 
  X, 
  Sparkles, 
  Globe2, 
  BrainCircuit, 
  CheckCircle2, 
  ShieldCheck, 
  TrendingUp, 
  Heart,
  FileText,
  CheckSquare
} from 'lucide-react';

interface CommunityMilestoneModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CommunityMilestoneModal({ isOpen, onClose }: CommunityMilestoneModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const testimonials = [
    {
      name: "Elena Vance",
      role: "Lead Platform Engineer at Stripe",
      avatarBg: "bg-blue-600",
      initials: "EV",
      badge: "Power User",
      quote: "Keeper replaced three separate notes & scratchpad tools. The conversational memory extraction lets me dump raw technical thoughts and retrieve them flawlessly during standups.",
      metric: "1,420 memories saved"
    },
    {
      name: "Dr. Marcus Thorne",
      role: "Genomics Researcher at Stanford",
      avatarBg: "bg-indigo-600",
      initials: "MT",
      badge: "Researcher",
      quote: "Keeping track of research citations, lab equipment tasks, and experimental observations used to be a chore. Keeper's AI agent parses my messy log notes into structured data in seconds.",
      metric: "890 documents organized"
    },
    {
      name: "Sarah Lin",
      role: "Director of Product at Figma",
      avatarBg: "bg-emerald-600",
      initials: "SL",
      badge: "Productivity Lead",
      quote: "The combination of natural language checklist generation and persistent memory makes this our team's favorite cognitive second brain. Truly transformative workflow.",
      metric: "2,350 tasks tracked"
    },
    {
      name: "Julian Rivera",
      role: "Author & Tech Journalist",
      avatarBg: "bg-purple-600",
      initials: "JR",
      badge: "Writer",
      quote: "I can drop an entire interview transcript or markdown document right onto Keeper, and it immediately isolates key facts and actionable follow-ups.",
      metric: "620 outlines written"
    }
  ];

  const recentCommunityMilestones = [
    { user: "Devon M.", action: "stored 18 sprint backlog items", time: "just now", type: "task" },
    { user: "Aoi T.", action: "archived Machine Learning lecture notes", time: "1m ago", type: "note" },
    { user: "Carlos G.", action: "added 6 personal preferences to memory", time: "3m ago", type: "memory" },
    { user: "Fatima K.", action: "imported 45 tasks from CSV log", time: "5m ago", type: "import" },
    { user: "Liam W.", action: "restored full workspace database", time: "8m ago", type: "backup" }
  ];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in font-sans"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Hero */}
        <div className="relative px-6 py-6 bg-gradient-to-br from-slate-900 via-slate-850 to-blue-950 text-white overflow-hidden shrink-0">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-10 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Top trust pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Community Milestone Achieved</span>
          </div>

          <h2 className="text-2xl font-display font-bold tracking-tight text-white sm:text-3xl">
            100,000+ People Trust Keeper
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-lg leading-relaxed">
            From engineers and researchers to product leaders and writers, over one hundred thousand thinkers use Keeper as their AI-powered cognitive memory and task vault.
          </p>

          {/* Core Numbers Ticker */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-white/10">
            <div className="bg-white/5 backdrop-blur-xs rounded-xl p-3 border border-white/10">
              <div className="text-xl sm:text-2xl font-bold font-display text-blue-400">100,000+</div>
              <div className="text-[10.5px] text-slate-300 font-medium mt-0.5 flex items-center gap-1">
                <Users className="w-3 h-3 text-blue-400" />
                Active Users
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-xs rounded-xl p-3 border border-white/10">
              <div className="text-xl sm:text-2xl font-bold font-display text-emerald-400">3.4M+</div>
              <div className="text-[10.5px] text-slate-300 font-medium mt-0.5 flex items-center gap-1">
                <BrainCircuit className="w-3 h-3 text-emerald-400" />
                Records Stored
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-xs rounded-xl p-3 border border-white/10">
              <div className="text-xl sm:text-2xl font-bold font-display text-amber-400 flex items-center gap-1">
                4.9 <Star className="w-4 h-4 fill-amber-400 text-amber-400 inline" />
              </div>
              <div className="text-[10.5px] text-slate-300 font-medium mt-0.5 flex items-center gap-1">
                <Heart className="w-3 h-3 text-amber-400" />
                User Satisfaction
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-xs rounded-xl p-3 border border-white/10">
              <div className="text-xl sm:text-2xl font-bold font-display text-indigo-400">65+</div>
              <div className="text-[10.5px] text-slate-300 font-medium mt-0.5 flex items-center gap-1">
                <Globe2 className="w-3 h-3 text-indigo-400" />
                Countries
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
          {/* User Testimonials Grid */}
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 font-mono flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Voices From The 100K Community
              </h3>
              <span className="text-[10px] text-slate-500 font-medium">Verified Active Accounts</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {testimonials.map((t, idx) => (
                <div 
                  key={idx}
                  className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between hover:border-slate-300 transition"
                >
                  <p className="text-xs text-slate-700 leading-relaxed italic mb-3">
                    &ldquo;{t.quote}&rdquo;
                  </p>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-full ${t.avatarBg} text-white font-bold text-xs flex items-center justify-center shrink-0`}>
                        {t.initials}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-800">{t.name}</div>
                        <div className="text-[10.5px] text-slate-500 truncate max-w-[140px]">{t.role}</div>
                      </div>
                    </div>
                    <span className="text-[9.5px] font-mono font-semibold bg-blue-50 text-blue-700 border border-blue-100 px-2 py-0.5 rounded-full shrink-0">
                      {t.badge}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Activity Feed */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-bold text-slate-800">Live Global Activity Pulse</span>
              </div>
              <span className="text-[10.5px] font-mono text-slate-500">1,842 users online now</span>
            </div>

            <div className="divide-y divide-slate-100 text-xs text-slate-600">
              {recentCommunityMilestones.map((item, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between first:pt-1 last:pb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-md bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                      {item.type === 'task' && <CheckSquare className="w-3 h-3 text-blue-600" />}
                      {item.type === 'note' && <FileText className="w-3 h-3 text-emerald-600" />}
                      {item.type === 'memory' && <BrainCircuit className="w-3 h-3 text-purple-600" />}
                      {item.type === 'import' && <TrendingUp className="w-3 h-3 text-indigo-600" />}
                      {item.type === 'backup' && <CheckCircle2 className="w-3 h-3 text-amber-600" />}
                    </div>
                    <span className="font-semibold text-slate-800">{item.user}</span>
                    <span className="text-slate-500 truncate max-w-[220px] sm:max-w-xs">{item.action}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 shrink-0">{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-100/80 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Encrypted, isolated and private for every individual user</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition cursor-pointer shadow-xs"
          >
            Continue to Workspace
          </button>
        </div>
      </div>
    </div>
  );
}
