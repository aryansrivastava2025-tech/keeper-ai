import React, { useEffect, useState, useRef } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../firebase';
import { UserProfile } from '../types';
import { Database, Cloud, CloudOff, LogIn, LogOut, User, CheckCircle2 } from 'lucide-react';

interface FirebaseBannerProps {
  user: UserProfile | null;
  onUserChanged: (user: UserProfile | null) => void;
}

export default function FirebaseBanner({ user, onUserChanged }: FirebaseBannerProps) {
  const [loading, setLoading] = useState(true);
  const currentUserUidRef = useRef<string | undefined>(undefined);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setLoading(false);

      const activeUid = firebaseUser?.uid;
      if (activeUid === currentUserUidRef.current) {
        return;
      }
      currentUserUidRef.current = activeUid;

      if (firebaseUser) {
        const profile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
        };
        onUserChanged(profile);
      } else {
        onUserChanged(null);
      }
    });

    return unsubscribe;
  }, [onUserChanged]);

  const handleSignIn = async () => {
    if (!isFirebaseConfigured) return;
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Google sign in failed:", err);
    }
  };

  const handleSignOut = async () => {
    if (!isFirebaseConfigured) return;
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Sign out failed:", err);
    }
  };

  if (!isFirebaseConfigured) {
    return (
      <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-sm font-sans shrink-0">
        <div className="flex items-center gap-2">
          <CloudOff className="w-5 h-5 text-amber-600 shrink-0" />
          <span>
            <strong>Local Sandbox Mode:</strong> Firebase database is not yet provisioned. Your agent data will temporarily save in browser local storage.
          </span>
        </div>
        <div className="bg-amber-100/60 text-amber-900 border border-amber-200 px-3 py-1 rounded-md text-xs font-mono font-bold self-start md:self-auto uppercase">
          Pre-deployment Demo
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-slate-50 border border-slate-200 text-slate-500 px-4 py-3 rounded-xl flex items-center gap-2 text-sm shrink-0">
        <div className="animate-spin rounded-full h-4 w-4 border-2 border-slate-400 border-t-transparent" />
        <span>Synchronizing with Firebase cloud...</span>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 text-slate-800 px-4 py-3 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-50 border border-blue-100 text-blue-600 rounded-lg shrink-0">
          <Cloud className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-sm text-slate-800">Firebase Storage Connected</span>
            <span className="flex items-center gap-1 bg-green-50 border border-green-200 text-green-700 text-[10px] px-2 py-0.5 rounded-full font-sans font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" /> Real-time Sync
            </span>
          </div>
          <p className="text-xs text-slate-500 font-sans mt-0.5">
            {user ? `Active User Profile: ${user.displayName || user.email}` : "Standalone browser mode. Sign in to backup data to Firestore."}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {user ? (
          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 pl-3 pr-1 py-1 rounded-lg">
            <div className="flex items-center gap-1.5 text-xs text-slate-700 font-sans font-medium">
              <User className="w-3.5 h-3.5 text-slate-500" />
              <span className="max-w-[120px] truncate">{user.displayName || 'Authorized'}</span>
            </div>
            <button
              onClick={handleSignOut}
              className="px-2.5 py-1.5 bg-white hover:bg-rose-50 hover:text-rose-600 border border-slate-200 hover:border-rose-200 text-slate-600 rounded-md text-xs font-sans font-semibold transition duration-150 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out
            </button>
          </div>
        ) : (
          <button
            onClick={handleSignIn}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 hover:-translate-y-0.5 text-white rounded-lg text-xs font-sans font-semibold transition-all duration-150 flex items-center gap-2 shadow-sm cursor-pointer"
          >
            <LogIn className="w-4 h-4 text-blue-200" />
            Sign in with Google
          </button>
        )}
      </div>
    </div>
  );
}
