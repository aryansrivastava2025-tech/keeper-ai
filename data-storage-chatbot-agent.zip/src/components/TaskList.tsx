import React, { useState } from 'react';
import { Task } from '../types';
import { CheckSquare, Square, Trash2, ShieldAlert, CheckCircle, Circle, PlaySquare } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onToggle: (id: string, completed: boolean) => void;
  onDelete: (id: string) => void;
  onAdd: (title: string) => void;
}

export default function TaskList({ tasks, onToggle, onDelete, onAdd }: TaskListProps) {
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [newTitle, setNewTitle] = useState('');

  const filteredTasks = tasks.filter(t => {
    if (filter === 'active') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAdd(newTitle.trim());
    setNewTitle('');
  };

  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden font-sans border border-slate-200 rounded-2xl shadow-sm">
      {/* Header Panel */}
      <div className="p-4 border-b border-slate-200 bg-slate-50/50 shrink-0 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5">
            <CheckSquare className="w-5 h-5 text-blue-650" />
            <h2 className="font-display font-semibold text-base text-slate-800">Tasks Checklist</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">Goal tracking & actionable tasks</p>
        </div>
        
        {tasks.length > 0 && (
          <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 border border-slate-200 px-2 py-0.5 rounded-full shrink-0">
            {completedCount}/{tasks.length} Completed
          </span>
        )}
      </div>

      {/* Quick Add To-Do */}
      <form onSubmit={handleSubmit} className="p-3 border-b border-slate-200 bg-slate-50/20 shrink-0 flex gap-2">
        <input 
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Add manual task... (e.g. 'Draft presentation deck')"
          className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition duration-150"
        />
        <button 
          type="submit"
          className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold cursor-pointer shrink-0 transition shadow-xs"
        >
          Add Task
        </button>
      </form>

      {/* Filter toolbar */}
      <div className="p-3 border-b border-slate-200 bg-slate-50/10 shrink-0 flex gap-1.5">
        {(['all', 'active', 'completed'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1 rounded-lg text-[10px] font-bold capitalize transition cursor-pointer border ${
              filter === f 
                ? 'bg-blue-50 text-blue-600 border-blue-200' 
                : 'bg-slate-100 hover:bg-slate-200 border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {f} List
          </button>
        ))}
      </div>

      {/* Task Rows List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {filteredTasks.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4">
            <CheckCircle className="w-8 h-8 text-slate-350 mb-2 stroke-1" />
            <p className="text-xs text-slate-500 font-medium">No tasks recorded</p>
            <p className="text-[10px] text-slate-450 mt-0.5 max-w-[200px]">
              {filter === 'completed' 
                ? "You haven't checked any tasks off yet." 
                : "Ask Keeper to save tasks from your discussions."
              }
            </p>
          </div>
        ) : (
          filteredTasks.map(task => (
            <div 
              key={task.id}
              onClick={() => onToggle(task.id, !task.completed)}
              className={`p-3 border rounded-xl flex items-center justify-between gap-3 cursor-pointer select-none transition-all duration-150 ${
                task.completed 
                  ? 'bg-slate-50/60 border-slate-150 text-slate-400' 
                  : 'bg-slate-50 border border-slate-200 text-slate-800 hover:bg-blue-50/10 hover:border-blue-250 hover:shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <button 
                  className={`p-0.5 rounded transition ${
                    task.completed ? 'text-blue-600' : 'text-slate-400 hover:text-blue-600'
                  }`}
                >
                  {task.completed ? (
                    <CheckSquare className="w-4 h-4 shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 shrink-0" />
                  )}
                </button>
                <span className={`text-xs truncate transition ${
                  task.completed ? 'line-through decoration-slate-350 text-slate-400' : 'font-sans font-medium'
                }`}>
                  {task.title}
                </span>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(task.id);
                }}
                className="p-2 hover:bg-rose-50 hover:text-rose-600 text-slate-400 rounded-md transition cursor-pointer hover:border-rose-200 hover:border"
                title="Remove task"
              >
                <Trash2 className="w-3.5 h-3.5 shrink-0" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
