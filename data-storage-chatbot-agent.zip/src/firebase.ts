import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Detect if configuration is set to default placeholders
export const isFirebaseConfigured = 
  firebaseConfig && 
  firebaseConfig.apiKey !== "dummy-api-key" && 
  firebaseConfig.projectId !== "dummy-project";

let dbInstance: any = null;
let authInstance: any = null;

if (isFirebaseConfigured) {
  try {
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    dbInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    authInstance = getAuth(app);
  } catch (err) {
    console.error("Failed to initialize Firebase services:", err);
  }
}

export const db = dbInstance;
export const auth = authInstance;
