import React, { useState, useEffect, useCallback, useRef } from 'react';
import FirebaseBanner from './components/FirebaseBanner';
import ChatContainer from './components/ChatContainer';
import MemoryList from './components/MemoryList';
import NoteEditor from './components/NoteEditor';
import TaskList from './components/TaskList';
import FileImporter from './components/FileImporter';
import CommunityMilestoneModal from './components/CommunityMilestoneModal';
import { 
  Memory, 
  Note, 
  Task, 
  Message, 
  UserProfile 
} from './types';
import { 
  getMemories, saveMemory, deleteMemory,
  getNotes, saveNote, updateNote, deleteNote,
  getTasks, saveTask, updateTask, deleteTask,
  getMessages, saveMessage, clearMessages
} from './lib/storage';
import { 
  BrainCircuit, 
  FileText, 
  CheckSquare, 
  Bot, 
  Sparkles,
  RefreshCw,
  FolderOpen,
  FileUp,
  Star,
  Users
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'memories' | 'notes' | 'tasks' | 'importer'>('memories');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [communityModalOpen, setCommunityModalOpen] = useState(false);

  // Storage states
  const [memories, setMemories] = useState<Memory[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: number; content: string } | null>(null);

  // System notification flags for flash animations
  const [tabNotification, setTabNotification] = useState<{
    memories: boolean;
    notes: boolean;
    tasks: boolean;
  }>({ memories: false, notes: false, tasks: false });

  // Keep track of the latest user state in a ref to handle async boundaries during login/logout
  const userRef = useRef<UserProfile | null>(user);

  // Load user-specific storage when user profile changes
  const loadUserData = useCallback(async (currentProfile: UserProfile | null) => {
    try {
      const uId = currentProfile?.uid;
      const [allMemories, allNotes, allTasks, allMessages] = await Promise.all([
        getMemories(uId),
        getNotes(uId),
        getTasks(uId),
        getMessages(uId)
      ]);
      setMemories(allMemories);
      setNotes(allNotes);
      setTasks(allTasks);
      setMessages(allMessages);
    } catch (err) {
      console.error("Failed to load user storage data:", err);
    }
  }, []);

  useEffect(() => {
    userRef.current = user;
    loadUserData(user);
    setChatLoading(false); // Reset agent loading and make chat interactable on login/logout
  }, [user, loadUserData]);

  const handleUserChanged = useCallback((profile: UserProfile | null) => {
    setUser(profile);
  }, []);

  // 1. Memory Events
  const handleAddMemory = async (content: string, category: string) => {
    const mem = await saveMemory({ content, category }, user?.uid);
    setMemories(prev => [...prev, mem]);
  };

  const handleDeleteMemory = async (id: string) => {
    await deleteMemory(id, user?.uid);
    setMemories(prev => prev.filter(m => m.id !== id));
  };

  // 2. Note Events
  const handleAddNote = async (title: string, content: string) => {
    const nt = await saveNote({ title, content }, user?.uid);
    setNotes(prev => [...prev, nt]);
  };

  const handleUpdateNote = async (id: string, updates: Partial<Note>) => {
    await updateNote(id, updates, user?.uid);
    setNotes(prev => prev.map(n => n.id === id ? { ...n, ...updates, updatedAt: Date.now() } : n));
  };

  const handleDeleteNote = async (id: string) => {
    await deleteNote(id, user?.uid);
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  // 3. Task Events
  const handleAddTask = async (title: string) => {
    const tk = await saveTask({ title, completed: false }, user?.uid);
    setTasks(prev => [...prev, tk]);
  };

  const handleToggleTask = async (id: string, completed: boolean) => {
    await updateTask(id, { completed }, user?.uid);
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed } : t));
  };

  const handleDeleteTask = async (id: string) => {
    await deleteTask(id, user?.uid);
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // 4. Clear chat thread session
  const handleClearChat = async () => {
    await clearMessages(user?.uid);
    setMessages([]);
  };

  // Special file integration helpers
  const handleAttachToChat = useCallback((file: { name: string; size: number; content: string } | null) => {
    setAttachedFile(file);
  }, []);

  const handleImportBackup = async (backup: { memories?: Memory[]; notes?: Note[]; tasks?: Task[] }) => {
    if (backup.memories && Array.isArray(backup.memories)) {
      for (const m of backup.memories) {
        if (m.content) {
          await saveMemory({ content: m.content, category: m.category || 'imported' }, user?.uid);
        }
      }
    }
    if (backup.notes && Array.isArray(backup.notes)) {
      for (const n of backup.notes) {
        if (n.title && n.content) {
          await saveNote({ title: n.title, content: n.content }, user?.uid);
        }
      }
    }
    if (backup.tasks && Array.isArray(backup.tasks)) {
      for (const t of backup.tasks) {
        if (t.title) {
          await saveTask({ title: t.title, completed: !!t.completed }, user?.uid);
        }
      }
    }
    await loadUserData(user);
    triggerNotification('memories');
    triggerNotification('notes');
    triggerNotification('tasks');
  };

  // Notification indicator flasher helper
  const triggerNotification = (tab: 'memories' | 'notes' | 'tasks') => {
    setTabNotification(prev => ({ ...prev, [tab]: true }));
    // Auto clear after 2 seconds
    setTimeout(() => {
      setTabNotification(prev => ({ ...prev, [tab]: false }));
    }, 2800);
  };

  // 5. Cognitive Agent Reasoning Loop
  const handleSendMessage = async (rawText: string) => {
    if ((!rawText.trim() && !attachedFile) || chatLoading) return;

    // Build the finalized instruction with raw attached file content if any
    let finalPrompt = rawText;
    if (attachedFile) {
      finalPrompt = `[Attached File: ${attachedFile.name} (${(attachedFile.size / 1024).toFixed(1)} KB)]\n` +
                    `\`\`\`text\n${attachedFile.content}\n\`\`\`\n\n` +
                    `${rawText || "Please analyze this file and extract tasks, document notes, or factual memories if applicable."}`;
    }

    setAttachedFile(null); // Reset attachment

    // Capture the exact user context when the message sending was initiated
    const sendingUserId = userRef.current?.uid;

    // Create user message
    const userMsg: Message = {
      id: 'msg_user_' + Math.random().toString(36).substring(2, 11),
      role: 'user',
      parts: [{ text: finalPrompt }],
      createdAt: Date.now()
    };

    // Append to local state and db
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    await saveMessage(userMsg, user?.uid);

    setChatLoading(true);

    try {
      // Build current local storage summary to inject into the system instructions
      const storageSummary = {
        memories: memories.map(m => ({ id: m.id, content: m.content, category: m.category })),
        notes: notes.map(n => ({ id: n.id, title: n.title, content: n.content })),
        tasks: tasks.map(t => ({ id: t.id, title: t.title, completed: t.completed }))
      };

      // Turn 1: request model action planning
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages,
          storageSummary
        })
      });

      // Quick guard: if user sessions transitioned during Turn 1 network IO, dismiss the request
      if (userRef.current?.uid !== sendingUserId) {
        console.log("User changed in flight during Turn 1 fetch. Gracefully discarding agent transition.");
        return;
      }

      if (!response.ok) {
        throw new Error("Backend response failed, status: " + response.status);
      }

      const data = await response.json();
      
      let finalMessagesList = [...updatedMessages];

      // If model returned function calls, execute them
      if (data.functionCalls && Array.isArray(data.functionCalls)) {
        console.log("Agent planned function calls:", data.functionCalls);

        // Turn the model's call into a message object to preserve conversation history
        const modelCallMsg: Message = {
          id: 'msg_model_calls_' + Math.random().toString(36).substring(2, 11),
          role: 'model',
          parts: data.candidateContent?.parts || data.functionCalls.map((fc: any) => ({ functionCall: fc })),
          createdAt: Date.now()
        };

        if (userRef.current?.uid !== sendingUserId) return;

        finalMessagesList.push(modelCallMsg);
        await saveMessage(modelCallMsg, user?.uid);

        // Array to store results of executions
        const toolResultParts: any[] = [];

        // Execute each planned operation against our database adapter
        for (const call of data.functionCalls) {
          const { name, args } = call;
          let resultResponse: any = { status: 'success' };

          if (userRef.current?.uid !== sendingUserId) return;

          try {
            if (name === 'saveMemory') {
              const mem = await saveMemory({ content: args.content, category: args.category }, user?.uid);
              setMemories(prev => [...prev, mem]);
              triggerNotification('memories');
              setActiveTab('memories'); // Swerve focus so user views it
              resultResponse = { result: "Memory saved successfully", id: mem.id };
            } 
            else if (name === 'deleteMemory') {
              await deleteMemory(args.id, user?.uid);
              setMemories(prev => prev.filter(m => m.id !== args.id));
              triggerNotification('memories');
              resultResponse = { result: "Memory deleted successfully", id: args.id };
            } 
            else if (name === 'createNote') {
              const nt = await saveNote({ title: args.title, content: args.content }, user?.uid);
              setNotes(prev => [...prev, nt]);
              triggerNotification('notes');
              setActiveTab('notes');
              resultResponse = { result: "Document note created successfully", id: nt.id };
            } 
            else if (name === 'updateNote') {
              await updateNote(args.id, { content: args.content, title: args.title }, user?.uid);
              setNotes(prev => prev.map(n => n.id === args.id ? { ...n, title: args.title || n.title, content: args.content, updatedAt: Date.now() } : n));
              triggerNotification('notes');
              setActiveTab('notes');
              resultResponse = { result: "Note updated successfully", id: args.id };
            } 
            else if (name === 'deleteNote') {
              await deleteNote(args.id, user?.uid);
              setNotes(prev => prev.filter(n => n.id !== args.id));
              triggerNotification('notes');
              resultResponse = { result: "Document deleted successfully", id: args.id };
            } 
            else if (name === 'createTask') {
              const tk = await saveTask({ title: args.title, completed: false }, user?.uid);
              setTasks(prev => [...prev, tk]);
              triggerNotification('tasks');
              setActiveTab('tasks');
              resultResponse = { result: "Task added successfully", id: tk.id };
            } 
            else if (name === 'updateTask') {
              await updateTask(args.id, { completed: args.completed }, user?.uid);
              setTasks(prev => prev.map(t => t.id === args.id ? { ...t, completed: args.completed } : t));
              triggerNotification('tasks');
              setActiveTab('tasks');
              resultResponse = { result: "Task updated successfully", id: args.id };
            } 
            else if (name === 'deleteTask') {
              await deleteTask(args.id, user?.uid);
              setTasks(prev => prev.filter(t => t.id !== args.id));
              triggerNotification('tasks');
              resultResponse = { result: "Task deleted successfully", id: args.id };
            }
          } catch (exc: any) {
            console.error(`Failed tool call execution (${name}):`, exc);
            resultResponse = { status: 'failure', error: exc.message || String(exc) };
          }

          toolResultParts.push({
            functionResponse: {
              name,
              response: resultResponse,
              id: call.id
            }
          });
        }

        if (userRef.current?.uid !== sendingUserId) return;

        // Build tool execution result log message
        const responseLogMsg: Message = {
          id: 'msg_tool_resp_' + Math.random().toString(36).substring(2, 11),
          role: 'user', // Tool responses count conceptually as user responses to Gemini
          parts: toolResultParts,
          createdAt: Date.now()
        };
        finalMessagesList.push(responseLogMsg);
        await saveMessage(responseLogMsg, user?.uid);

        // Update memories locally prior to final speak
        const updatedStorageSummary = {
          memories: memories.map(m => ({ id: m.id, content: m.content, category: m.category })),
          notes: notes.map(n => ({ id: n.id, title: n.title, content: n.content })),
          tasks: tasks.map(t => ({ id: t.id, title: t.title, completed: t.completed }))
        };

        // Turn 2: Feed tool responses back to model to let it speech-synthesize its final confirmation
        const talkResponse = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: finalMessagesList,
            storageSummary: updatedStorageSummary
          })
        });

        if (userRef.current?.uid !== sendingUserId) return;

        if (!talkResponse.ok) {
          throw new Error("Secondary talk turn failed: " + talkResponse.status);
        }

        const talkData = await talkResponse.json();

        // Save model's final conversational message
        const finalModelMsg: Message = {
          id: 'msg_model_final_' + Math.random().toString(36).substring(2, 11),
          role: 'model',
          parts: [{ text: talkData.text || "Done! Executed those database tools." }],
          createdAt: Date.now()
        };

        if (userRef.current?.uid !== sendingUserId) return;

        setMessages([...finalMessagesList, finalModelMsg]);
        await saveMessage(finalModelMsg, user?.uid);

      } else {
        // Model simply reply conversational text directly with no tools needed
        const simpleModelMsg: Message = {
          id: 'msg_model_conv_' + Math.random().toString(36).substring(2, 11),
          role: 'model',
          parts: [{ text: data.text || "I hear you! How can I help you save things today?" }],
          createdAt: Date.now()
        };

        if (userRef.current?.uid !== sendingUserId) return;

        setMessages([...finalMessagesList, simpleModelMsg]);
        await saveMessage(simpleModelMsg, user?.uid);
      }

    } catch (err: any) {
      if (userRef.current?.uid !== sendingUserId) {
        console.log("Ignoring error caught on secondary/stale auth context.");
        return;
      }
      console.error("Agent chat round failed:", err);
      const errMsg: Message = {
        id: 'msg_err_' + Date.now(),
        role: 'model',
        parts: [{ text: `🚨 Error communicating with cognitive agent: ${err.message || 'Check connection'}. Make sure your process of setting up Gemini API is active.` }],
        createdAt: Date.now()
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      // Clean up loader is handled by state triggers, but we can call it if current session is active
      if (userRef.current?.uid === sendingUserId) {
        setChatLoading(false);
      }
    }
  };

  return (
    <div className="w-screen h-screen bg-slate-50 font-sans text-slate-800 flex flex-col overflow-hidden">
      
      {/* Upper Navigation Bar */}
      <header className="px-6 py-4 border-b border-slate-200 bg-white shrink-0 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-650">
            <Bot className="w-5 h-5 stroke-[1.8]" />
          </div>
          <div>
            <h1 className="font-display font-semibold text-base tracking-tight text-slate-800 flex items-center gap-2">
              Keeper Applet <span className="text-[10px] bg-slate-100 border border-slate-200 text-slate-600 px-2 py-0.5 rounded-full font-mono font-bold lowercase">v1.2.0</span>
            </h1>
            <p className="text-[10px] text-slate-500 font-sans mt-0.5 font-medium">Autonomous natural-language memory agent and secure bento databases</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* 100K Users Community Milestone Showcase Button */}
          <button
            type="button"
            onClick={() => setCommunityModalOpen(true)}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-slate-50 hover:bg-blue-50/80 border border-slate-200 hover:border-blue-300 transition group cursor-pointer shadow-2xs"
            title="Click to view 100,000+ community milestone details"
          >
            {/* Avatar Stack */}
            <div className="flex -space-x-2 overflow-hidden shrink-0">
              <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-blue-600 text-white font-bold text-[9px] items-center justify-center">EV</span>
              <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-indigo-600 text-white font-bold text-[9px] items-center justify-center">MT</span>
              <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-emerald-600 text-white font-bold text-[9px] items-center justify-center">SL</span>
              <span className="inline-flex h-6 w-6 rounded-full ring-2 ring-white bg-amber-600 text-white font-bold text-[8.5px] items-center justify-center">+100k</span>
            </div>

            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-slate-800 group-hover:text-blue-600 transition">100k+</span>
                <span className="text-xs text-slate-500 font-medium hidden sm:inline">people using Keeper</span>
              </div>
              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200/60">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>4.9</span>
              </span>
            </div>
          </button>

          <div className="hidden lg:flex items-center gap-2 text-xs font-mono text-slate-500">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600/40" />
            <span>Agent Sandbox Connected</span>
          </div>
        </div>
      </header>

      {/* Main split-view dashboard body */}
      <main className="flex-1 overflow-hidden p-6 gap-6 flex flex-col md:flex-row min-h-0">
        
        {/* Left Column Chatting Frame */}
        <div className="w-full md:w-[42%] lg:w-[38%] h-full flex flex-col shrink-0 min-h-0">
          <ChatContainer 
            messages={messages}
            onSendMessage={handleSendMessage}
            onClearHistory={handleClearChat}
            loading={chatLoading}
            attachedFile={attachedFile}
            onAttachFile={handleAttachToChat}
            onOpenCommunityModal={() => setCommunityModalOpen(true)}
          />
        </div>

        {/* Right Column Bento Database Store */}
        <div className="flex-1 h-full flex flex-col gap-5 min-h-0">
          {/* Authentication banner control */}
          <FirebaseBanner user={user} onUserChanged={handleUserChanged} />

          {/* Database panel Container */}
          <div className="flex-1 flex flex-col overflow-hidden bg-white border border-slate-200 rounded-2xl min-h-0 shadow-xs">
            
            {/* Database custom navigation tab pills */}
            <div className="px-4 py-3 bg-slate-50/50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 text-xs font-display font-semibold text-slate-600">
                <FolderOpen className="w-4 h-4 text-slate-500" />
                <span>Keeper Memory Database</span>
              </div>
              
              <div className="flex bg-slate-100 border border-slate-200/50 rounded-xl p-0.5 gap-0.5 text-xs font-sans">
                {[
                  { id: 'memories', label: 'Facts', icon: BrainCircuit, count: memories.length },
                  { id: 'notes', label: 'Documents', icon: FileText, count: notes.length },
                  { id: 'tasks', label: 'Checklist', icon: CheckSquare, count: tasks.length },
                  { id: 'importer', label: 'Import', icon: FileUp, count: 0 }
                ].map(tab => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  const isNotified = tabNotification[tab.id as 'memories' | 'notes' | 'tasks'];
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`relative px-3.5 py-1.5 rounded-lg text-xs font-sans font-semibold transition duration-150 flex items-center gap-1.5 cursor-pointer ${
                        isActive
                          ? 'bg-white text-blue-600 border border-slate-200/60 shadow-xs font-bold'
                          : 'text-slate-500 hover:text-slate-800 border border-transparent font-medium'
                      }`}
                    >
                      <Icon className={`w-3.5 h-3.5 transition ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span>{tab.label}</span>
                      {tab.count > 0 && (
                        <span className="text-[9px] font-mono font-bold bg-slate-50 text-slate-500 px-1 py-0.5 rounded border border-slate-200 leading-none shrink-0">
                          {tab.count}
                        </span>
                      )}

                      {/* Flash indicator animation when agent updates database */}
                      {isNotified && (
                        <span className="absolute -top-1 -right-1 block h-2.5 w-2.5 rounded-full bg-blue-600 border border-white animate-ping"></span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Displaying active tab viewer panel */}
            <div className="flex-1 overflow-hidden">
              {activeTab === 'memories' && (
                <MemoryList 
                  memories={memories}
                  onDelete={handleDeleteMemory}
                  onAdd={handleAddMemory}
                />
              )}
              {activeTab === 'notes' && (
                <NoteEditor 
                  notes={notes}
                  onAdd={handleAddNote}
                  onUpdate={handleUpdateNote}
                  onDelete={handleDeleteNote}
                />
              )}
              {activeTab === 'tasks' && (
                <TaskList 
                  tasks={tasks}
                  onToggle={handleToggleTask}
                  onDelete={handleDeleteTask}
                  onAdd={handleAddTask}
                />
              )}
              {activeTab === 'importer' && (
                <FileImporter 
                  userId={user?.uid}
                  onAddMemory={handleAddMemory}
                  onAddNote={handleAddNote}
                  onAddTask={handleAddTask}
                  memories={memories}
                  notes={notes}
                  tasks={tasks}
                  onImportBackup={handleImportBackup}
                  onAttachToChat={handleAttachToChat}
                />
              )}
            </div>

          </div>
        </div>

      </main>

      {/* Community Milestone 100K Showcase Modal */}
      <CommunityMilestoneModal 
        isOpen={communityModalOpen} 
        onClose={() => setCommunityModalOpen(false)} 
      />
    </div>
  );
}
