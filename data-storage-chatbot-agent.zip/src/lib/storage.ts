import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db, auth, isFirebaseConfigured } from '../firebase';
import { Memory, Note, Task, Message } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
  };
}

function handleFirestoreError(error: any, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Memory Operations
export async function getMemories(userId?: string): Promise<Memory[]> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const q = query(collection(db, 'memories'), where('userId', '==', userId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(d => d.data() as Memory);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'memories');
    }
  } else {
    const local = localStorage.getItem('agent_memories');
    return local ? JSON.parse(local) : [];
  }
}

export async function saveMemory(memory: Omit<Memory, 'id' | 'createdAt'>, userId?: string): Promise<Memory> {
  const newMemory: Memory = {
    ...memory,
    id: 'mem_' + Math.random().toString(36).substring(2, 11),
    createdAt: Date.now()
  };

  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'memories', newMemory.id);
      await setDoc(docRef, { ...newMemory, userId });
      return newMemory;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `memories/${newMemory.id}`);
    }
  } else {
    const memories = await getMemories();
    memories.push(newMemory);
    localStorage.setItem('agent_memories', JSON.stringify(memories));
    return newMemory;
  }
}

export async function deleteMemory(id: string, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'memories', id);
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `memories/${id}`);
    }
  } else {
    const memories = await getMemories();
    const updated = memories.filter(m => m.id !== id);
    localStorage.setItem('agent_memories', JSON.stringify(updated));
  }
}

// Note Operations
export async function getNotes(userId?: string): Promise<Note[]> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const q = query(collection(db, 'notes'), where('userId', '==', userId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(d => d.data() as Note);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'notes');
    }
  } else {
    const local = localStorage.getItem('agent_notes');
    return local ? JSON.parse(local) : [];
  }
}

export async function saveNote(note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>, userId?: string): Promise<Note> {
  const newNote: Note = {
    ...note,
    id: 'note_' + Math.random().toString(36).substring(2, 11),
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'notes', newNote.id);
      await setDoc(docRef, { ...newNote, userId });
      return newNote;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `notes/${newNote.id}`);
    }
  } else {
    const notes = await getNotes();
    notes.push(newNote);
    localStorage.setItem('agent_notes', JSON.stringify(notes));
    return newNote;
  }
}

export async function updateNote(id: string, updates: Partial<Omit<Note, 'id' | 'createdAt'>>, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'notes', id);
      await updateDoc(docRef, { ...updates, updatedAt: Date.now() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notes/${id}`);
    }
  } else {
    const notes = await getNotes();
    const updated = notes.map(n => n.id === id ? { ...n, ...updates, updatedAt: Date.now() } : n);
    localStorage.setItem('agent_notes', JSON.stringify(updated));
  }
}

export async function deleteNote(id: string, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'notes', id);
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `notes/${id}`);
    }
  } else {
    const notes = await getNotes();
    const updated = notes.filter(n => n.id !== id);
    localStorage.setItem('agent_notes', JSON.stringify(updated));
  }
}

// Task Operations
export async function getTasks(userId?: string): Promise<Task[]> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const q = query(collection(db, 'tasks'), where('userId', '==', userId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(d => d.data() as Task);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'tasks');
    }
  } else {
    const local = localStorage.getItem('agent_tasks');
    return local ? JSON.parse(local) : [];
  }
}

export async function saveTask(task: Omit<Task, 'id' | 'createdAt'>, userId?: string): Promise<Task> {
  const newTask: Task = {
    ...task,
    id: 'task_' + Math.random().toString(36).substring(2, 11),
    createdAt: Date.now()
  };

  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'tasks', newTask.id);
      await setDoc(docRef, { ...newTask, userId });
      return newTask;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `tasks/${newTask.id}`);
    }
  } else {
    const tasks = await getTasks();
    tasks.push(newTask);
    localStorage.setItem('agent_tasks', JSON.stringify(tasks));
    return newTask;
  }
}

export async function updateTask(id: string, updates: Partial<Omit<Task, 'id' | 'createdAt'>>, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'tasks', id);
      await updateDoc(docRef, updates);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tasks/${id}`);
    }
  } else {
    const tasks = await getTasks();
    const updated = tasks.map(t => t.id === id ? { ...t, ...updates } : t);
    localStorage.setItem('agent_tasks', JSON.stringify(updated));
  }
}

export async function deleteTask(id: string, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'tasks', id);
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `tasks/${id}`);
    }
  } else {
    const tasks = await getTasks();
    const updated = tasks.filter(t => t.id !== id);
    localStorage.setItem('agent_tasks', JSON.stringify(updated));
  }
}

// Chat Messages Operations
export async function getMessages(userId?: string): Promise<Message[]> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const q = query(
        collection(db, 'messages'), 
        where('userId', '==', userId),
        orderBy('createdAt', 'asc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(d => d.data() as Message);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'messages');
    }
  } else {
    const local = localStorage.getItem('agent_messages');
    return local ? JSON.parse(local) : [];
  }
}

export async function saveMessage(msg: Message, userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const docRef = doc(db, 'messages', msg.id);
      await setDoc(docRef, { ...msg, userId });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `messages/${msg.id}`);
    }
  } else {
    const msgs = await getMessages();
    msgs.push(msg);
    localStorage.setItem('agent_messages', JSON.stringify(msgs));
  }
}

export async function clearMessages(userId?: string): Promise<void> {
  if (isFirebaseConfigured && auth?.currentUser && userId) {
    try {
      const msgs = await getMessages(userId);
      for (const msg of msgs) {
        await deleteDoc(doc(db, 'messages', msg.id));
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'messages');
    }
  } else {
    localStorage.removeItem('agent_messages');
  }
}
