export interface Memory {
  id: string;
  content: string;
  category: string;
  createdAt: number;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  createdAt: number;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  parts: {
    text?: string;
    functionCall?: {
      name: string;
      args: any;
      id?: string;
    };
    functionResponse?: {
      name: string;
      response: any;
      id?: string;
    };
  }[];
  createdAt: number;
  isActionLog?: boolean;
  actionDetails?: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
}
