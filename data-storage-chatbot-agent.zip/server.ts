import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize GoogleGenAI SDK on the server using lazy lookup & validation
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY secret is required in environment variables");
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

app.use(express.json());

// List of available tools (Function Declarations) for our storage agent
const saveMemoryTool: FunctionDeclaration = {
  name: "saveMemory",
  description: "Saves a short factual piece of memory, preference, or fact about user (e.g. 'likes matcha tea', 'has a dog named Rex'). Use short, clear, general statements. Assign a short category like personal, professional, preference, facts.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      content: {
        type: Type.STRING,
        description: "The concrete fact to remember."
      },
      category: {
        type: Type.STRING,
        description: "The category for semantic grouping (e.g. 'personal', 'work', 'interest', 'tech')."
      }
    },
    required: ["content", "category"]
  }
};

const deleteMemoryTool: FunctionDeclaration = {
  name: "deleteMemory",
  description: "Deletes a previously saved memory or fact by its ID. Use this when the user requests to forget a specific fact.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      id: {
        type: Type.STRING,
        description: "The ID of the memory to delete."
      }
    },
    required: ["id"]
  }
};

const createNoteTool: FunctionDeclaration = {
  name: "createNote",
  description: "Creates a detailed, multi-line structured note, code snippet, design outline, journal, or article. Use markdown syntax in the content to keep it highly organized and polished.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: "The header or title of the note."
      },
      content: {
        type: Type.STRING,
        description: "The markdown-formatted body content of the note."
      }
    },
    required: ["title", "content"]
  }
};

const updateNoteTool: FunctionDeclaration = {
  name: "updateNote",
  description: "Updates the text content or title of an existing note by its ID.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      id: {
        type: Type.STRING,
        description: "The ID of the note to update."
      },
      content: {
        type: Type.STRING,
        description: "The updated markdown content."
      },
      title: {
        type: Type.STRING,
        description: "Optional updated title of the note."
      }
    },
    required: ["id", "content"]
  }
};

const deleteNoteTool: FunctionDeclaration = {
  name: "deleteNote",
  description: "Deletes a detailed note by its ID from storage.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      id: {
        type: Type.STRING,
        description: "The ID of the note to remove."
      }
    },
    required: ["id"]
  }
};

const createTaskTool: FunctionDeclaration = {
  name: "createTask",
  description: "Creates an actionable checkbox item in the user's checklist / to-do list.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: "The task title (e.g., 'Buy organic apples', 'Refactor backend middleware')."
      }
    },
    required: ["title"]
  }
};

const updateTaskTool: FunctionDeclaration = {
  name: "updateTask",
  description: "Updates an existing task's title or completed status.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      id: {
        type: Type.STRING,
        description: "The ID of the task to update."
      },
      completed: {
        type: Type.BOOLEAN,
        description: "True if the task is checked off, false if uncompleted."
      }
    },
    required: ["id", "completed"]
  }
};

const deleteTaskTool: FunctionDeclaration = {
  name: "deleteTask",
  description: "Permanently deletes a task from the to-do list using its ID.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      id: {
        type: Type.STRING,
        description: "The ID of the task to delete."
      }
    },
    required: ["id"]
  }
};

const agentTools = [
  saveMemoryTool,
  deleteMemoryTool,
  createNoteTool,
  updateNoteTool,
  deleteNoteTool,
  createTaskTool,
  updateTaskTool,
  deleteTaskTool
];

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", port: PORT });
});

// Primary Chat API Route hosting our Agent reasoning logic
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, storageSummary } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "messages array is required" });
    }

    const ai = getGeminiClient();

    // Dynamically build the system instructions injecting current database snapshot
    const memoriesStr = JSON.stringify(storageSummary?.memories || []);
    const notesStr = JSON.stringify(storageSummary?.notes || []);
    const tasksStr = JSON.stringify(storageSummary?.tasks || []);

    const systemInstruction = `You are "Keeper", an incredibly capable, full-stack conversational Data Storage Chatbot & Agent.
Your superpower is assisting users in managing, tracking, and recalling memories, detailed notes, and actionable checks.

You have access to a secure, private key-value and collections store of memories, notes, and tasks.
To help the user interact with this store, you have a set of custom database tools. You must use them!

CURRENT STORED DATABASE SNAPSHOT FOR SECURE ACCESS:
- Memories (Facts/preferences): ${memoriesStr}
- Notes (Markdown documents): ${notesStr}
- Tasks (Checklist items): ${tasksStr}

AGENT BEHAVIOR CODES:
1. AUTONOMOUS MEMORY CAPTURE: Actively listen for user details (personal facts, family, preferences, tech stacks, birthdays, hobbies, things they mention in passing) and call the "saveMemory" tool automatically! Do not always wait for them to explicitly ask you to remember.
2. DETAILED NOTETAKING: When requested to write lists, plans, code scripts, guides, outlines, ideas, brainstorms, or summaries, use the "createNote" tool containing beautiful Markdown format so they are preserved in their dashboard.
3. CHECKLIST OPERATIONS: When they give you tasks, schedules, or checklist orders, use "createTask", "updateTask", or "deleteTask" to track progress.
4. EXPLICIT DELETIONS: If they ask you to "forget" a memory or "bin" a note, call "deleteMemory" or "deleteNote" with the matching ID from the current snapshot.
5. CONTEXT-AWARE SPEAKING: Use the snapshot listed above to reply. If they ask about something you previously stored, fetch it from your contextual memory and show that you remember!
6. CLEAR CONFIRMATION: Briefly confirm what databases actions you've executed in your response text (e.g., "I've noted that you like black coffee and added a task to buy beans!"). Keeping replies friendly and focused.`;

    // Map message formats for Gemini @google/genai SDK
    // Each message contains { role: 'user' | 'model', parts: [ { text: string } OR { functionCall: ... } OR { functionResponse: ... } ] }
    const formattedContents = messages.map(msg => ({
      role: msg.role,
      parts: msg.parts.map((p: any) => {
        if (p.text) {
          return { text: p.text };
        }
        if (p.functionCall) {
          const fc: any = {
            name: p.functionCall.name,
            args: p.functionCall.args
          };
          if (p.functionCall.id) {
            fc.id = p.functionCall.id;
          }
          return { functionCall: fc };
        }
        if (p.functionResponse) {
          const fr: any = {
            name: p.functionResponse.name,
            response: p.functionResponse.response
          };
          if (p.functionResponse.id) {
            fr.id = p.functionResponse.id;
          }
          return { functionResponse: fr };
        }
        return p;
      })
    }));

    // Call the model with custom retry mechanism for transient overloaded servers and fallback model support
    let response;
    const attempts = 3;
    let delay = 1000;
    
    for (let i = 0; i < attempts; i++) {
       try {
         response = await ai.models.generateContent({
           model: "gemini-2.5-flash",
           contents: formattedContents,
           config: {
             systemInstruction,
             temperature: 0.2, // Low temperature for high precision and correct tool usage
             tools: [{ functionDeclarations: agentTools }]
           }
         });
         break; // Success! Exit retry loop
       } catch (err: any) {
         const errMsg = err.message || "";
         // Determine if this is an immediate quota failure (RESOURCE_EXHAUSTED or Daily quota exceeded) which can't be resolved with simple retry delays
         const isQuotaLimitExceeded = errMsg.includes("Quota exceeded") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("limit:") || errMsg.includes("quota exceeded");
         const isTransient = (errMsg.includes("503") || errMsg.includes("UNAVAILABLE") || errMsg.includes("429") || errMsg.includes("high demand") || err.status === 503 || err.status === 429) && !isQuotaLimitExceeded;
         
         if (isTransient && i < attempts - 1) {
           console.warn(`Transient overload detected on Gemini 2.5-flash (attempt ${i + 1}/${attempts}): ${errMsg}. Retrying in ${delay}ms...`);
           await new Promise(resolve => setTimeout(resolve, delay));
           delay *= 1.5;
         } else {
           // If we exhausted all attempts or if it is a general model load/quota error, fall back to "gemini-1.5-flash"
           console.warn(`Gemini 2.5-flash is currently unavailable or experiencing high-demand. Gracefully falling back to gemini-1.5-flash. Error was:`, errMsg);
           try {
             response = await ai.models.generateContent({
               model: "gemini-1.5-flash",
               contents: formattedContents,
               config: {
                 systemInstruction,
                 temperature: 0.2,
                 tools: [{ functionDeclarations: agentTools }]
               }
             });
             break; // Fallback succeeded! Exit retry loop
           } catch (fallbackErr: any) {
             throw new Error(`Gemini Agent failed: ${fallbackErr.message || fallbackErr} (Original error: ${errMsg})`);
           }
         }
       }
    }

    const candidate = response.candidates?.[0];
    const replyText = response.text || "";
    const functionCalls = response.functionCalls || null;

    res.json({
      text: replyText,
      functionCalls,
      candidateContent: candidate?.content
    });

  } catch (error: any) {
    console.error("Error in Agent logic endpoint:", error);
    res.status(500).json({ error: error.message || "An error occurred with the AI agent" });
  }
});

// Set up server assets streaming via Vite or Static Build files based on package type
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Keeper Fullstack Server] Applet available on http://localhost:${PORT}`);
  });
}

startServer();
